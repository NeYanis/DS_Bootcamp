#!/bin/bash

termgraph data.txt --color {red,green}